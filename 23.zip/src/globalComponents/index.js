import Gheader from './Gheader.vue'
const components = [Gheader]
const install =(vue)=>{
  components.map(item=>{
    vue.component(item.name,item)
  })
}
export default{
  install,
  Gheader
}